package com.example.studentrecruitmentapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;



import java.util.ArrayList;

public class JobNotificationActivity extends AppCompatActivity {

    private ListView jobListView;
    private ArrayList<String> jobNotifications;
    private ArrayAdapter<String> jobAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_notification);


        jobListView = findViewById(R.id.jobListView);


        jobNotifications = new ArrayList<>();
        jobNotifications.add("Software Developer at ByteWorks - Johannesburg");
        jobNotifications.add("IT Support Intern at TechConnect - Durban");
        jobNotifications.add("Junior Business Analyst at AdNotes - Cape Town");
        jobNotifications.add("Graduate Trainee at SoftCorp - Bloemfontein");


        jobAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, jobNotifications);


        jobListView.setAdapter(jobAdapter);
    }
}
