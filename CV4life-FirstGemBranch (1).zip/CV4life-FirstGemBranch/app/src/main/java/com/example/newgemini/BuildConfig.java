package com.example.newgemini;

public class BuildConfig {
    public static String apiKey = "AIzaSyC8iQVKN5ihiaMpyiilqfffIQq09Bpn2Tk";
}
