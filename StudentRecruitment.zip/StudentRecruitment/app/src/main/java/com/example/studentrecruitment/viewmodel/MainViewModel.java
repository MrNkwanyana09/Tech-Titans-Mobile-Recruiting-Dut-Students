package com.example.studentrecruitment.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.studentrecruitment.model.JobNotification;

import java.util.ArrayList;
import java.util.List;

public class MainViewModel extends ViewModel {
    private final MutableLiveData<List<JobNotification>> jobNotifications = new MutableLiveData<>();

    public MainViewModel() {
        // Initialize with sample data
        List<JobNotification> initialJobs = new ArrayList<>();
        initialJobs.add(new JobNotification(1, "Software Engineer", "Tech Corp", "London", 60000, "Full-time", 85, "2 days ago"));
        initialJobs.add(new JobNotification(2, "Data Analyst", "Data Inc", "Manchester", 45000, "Part-time", 78, "1 day ago"));
        initialJobs.add(new JobNotification(3, "Product Manager", "Innovate Ltd", "Remote", 75000, "Full-time", 92, "3 days ago"));
        jobNotifications.setValue(initialJobs);
    }

    public LiveData<List<JobNotification>> getJobNotifications() {
        return jobNotifications;
    }
}