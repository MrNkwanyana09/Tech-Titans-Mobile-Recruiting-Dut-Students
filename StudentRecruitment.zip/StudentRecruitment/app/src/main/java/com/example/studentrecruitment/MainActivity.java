package com.example.studentrecruitment;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.studentrecruitment.adapter.JobAdapter;
import com.example.studentrecruitment.databinding.ActivityMainBinding;
import com.example.studentrecruitment.viewmodel.MainViewModel;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private MainViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize View Binding
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize ViewModel
        viewModel = new ViewModelProvider(this).get(MainViewModel.class);

        // Set up RecyclerView
        binding.recyclerViewJobs.setLayoutManager(new LinearLayoutManager(this));
        JobAdapter adapter = new JobAdapter(viewModel.getJobNotifications().getValue());
        binding.recyclerViewJobs.setAdapter(adapter);

        // Observe LiveData
        viewModel.getJobNotifications().observe(this, jobs -> {
            adapter.notifyDataSetChanged();
        });
    }
}