package com.example.studentrecruitment.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studentrecruitment.R;
import com.example.studentrecruitment.model.JobNotification;

import java.util.List;

public class JobAdapter extends RecyclerView.Adapter<JobAdapter.JobViewHolder> {
    private final List<JobNotification> jobList;

    public JobAdapter(List<JobNotification> jobList) {
        this.jobList = jobList;
    }

    @NonNull
    @Override
    public JobViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_job_notification, parent, false);
        return new JobViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull JobViewHolder holder, int position) {
        JobNotification job = jobList.get(position);
        holder.tvJobTitle.setText(job.getTitle());
        holder.tvCompany.setText(job.getCompany());
        holder.tvLocation.setText(job.getLocation());
        holder.tvSalary.setText("£" + job.getSalary());
        holder.tvJobType.setText(job.getJobType());
        holder.tvMatchScore.setText(job.getMatchScore() + "%");
        holder.tvPostedTime.setText(job.getPostedTime());
        // ImageViews already have src set in XML (ic_company, ic_location, etc.)
    }

    @Override
    public int getItemCount() {
        return jobList.size();
    }

    static class JobViewHolder extends RecyclerView.ViewHolder {
        TextView tvJobTitle, tvCompany, tvLocation, tvSalary, tvJobType, tvMatchScore, tvPostedTime;
        ImageView ivCompanyIcon, ivLocationIcon, ivSalaryIcon, ivJobTypeIcon;

        JobViewHolder(@NonNull View itemView) {
            super(itemView);
            tvJobTitle = itemView.findViewById(R.id.tv_job_title);
            tvCompany = itemView.findViewById(R.id.tv_company);
            tvLocation = itemView.findViewById(R.id.tv_location);
            tvSalary = itemView.findViewById(R.id.tv_salary);
            tvJobType = itemView.findViewById(R.id.tv_job_type);
            tvMatchScore = itemView.findViewById(R.id.tv_match_score);
            tvPostedTime = itemView.findViewById(R.id.tv_posted_time);
            ivCompanyIcon = itemView.findViewById(R.id.iv_company_icon);
            ivLocationIcon = itemView.findViewById(R.id.iv_location_icon);
            ivSalaryIcon = itemView.findViewById(R.id.iv_salary_icon);
            ivJobTypeIcon = itemView.findViewById(R.id.iv_job_type_icon);
        }
    }
}