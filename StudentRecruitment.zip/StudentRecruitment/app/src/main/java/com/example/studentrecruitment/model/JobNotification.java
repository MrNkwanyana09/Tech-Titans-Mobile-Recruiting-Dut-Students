package com.example.studentrecruitment.model;

public class JobNotification {
    private final int id;
    private final String title;
    private final String company;
    private final String location;
    private final int salary;
    private final String jobType;
    private final int matchScore;
    private final String postedTime;

    public JobNotification(int id, String title, String company, String location,
                           int salary, String jobType, int matchScore, String postedTime) {
        this.id = id;
        this.title = title;
        this.company = company;
        this.location = location;
        this.salary = salary;
        this.jobType = jobType;
        this.matchScore = matchScore;
        this.postedTime = postedTime;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getCompany() {
        return company;
    }

    public String getLocation() {
        return location;
    }

    public int getSalary() {
        return salary;
    }

    public String getJobType() {
        return jobType;
    }

    public int getMatchScore() {
        return matchScore;
    }

    public String getPostedTime() {
        return postedTime;
    }

    @Override
    public String toString() {
        return "JobNotification{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", company='" + company + '\'' +
                ", location='" + location + '\'' +
                ", salary=" + salary +
                ", jobType='" + jobType + '\'' +
                ", matchScore=" + matchScore +
                ", postedTime='" + postedTime + '\'' +
                '}';
    }
}